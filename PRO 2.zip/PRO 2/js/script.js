var navbar = document.querySelector(".navbar");
var sidenav = document.querySelector(".side-nav");
function openNav(){
    sidenav.style.left="0";
}
function closeNav(){
    sidenav.style.left="-60%";
}